from django.apps import AppConfig


class GestionAlumnoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "gestion_alumno"
